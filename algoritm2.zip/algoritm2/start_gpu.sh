#!/bin/bash

echo "------------------------START Miner----------------------"
./gen -t cuda -a "NQ71 Y75M C5X9 FPSG GXTT 14YU 2MBE VFKC XTMK" -p pool.acemining.co:8443 -n "algo"
echo "------------------------END Miner----------------------"
echo "something went wrong or you exited"
