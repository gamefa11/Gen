#!/bin/bash

echo "------------------------START Miner----------------------"
./alogoritm -t cuda -a "NQ71Y75MC5X9FPSGGXTT14YU2MBEVFKCXTMK" -p pool.acemining.co:8443 -n "algo"
echo "------------------------END Miner----------------------"
echo "something went wrong or you exited"
